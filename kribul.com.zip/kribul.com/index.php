<?php include 'koneksi.php';?>
<!DOCTYPE html>
<html>
<head>
	<title>kribul.com</title>
	<style>

b{
 font-size: 25px;
 font-family: Calibri;
 font-weight: normal;
}
.text-google{
    border: 1px solid #bbb;
    padding: 10px;
    width: 300px;
}
.btn{
	border: 1px solid #bbb;
	 padding: 15px;
    width: 60px;
}
#kotak{
-webkit-border-radius:30px;
height:30px;
}
h2{
color: #color-black;

}

</style>

<script src="jquery.js" type="text/javascript"></script>
<script type="text/javascript">
 $(document).ready(function(){
  $(".text-google").keyup(function(){
   $.ajax({
    url : "search_google.php",
    type: "POST",
    data: "keyword="+$(".text-google").val(),
    success : function(data){
     $(".result").html(data);
    }
   })
   
  })
 })
</script>

	<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

<!--<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css" >-->
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="post-http://en.wikipedia.org/?search=*"></script>


</head>
<center>
<body background="img/foto.jpg">
<div class="container">
 <script src="jquery-3.2.1.min.js"></script>

        <!-- Memanggil Autocomplete.js -->
        <script src="jquery.autocomplete.min.js"></script>

        <script type="text/javascript">
            $(document).ready(function() {

                // Selector input yang akan menampilkan autocomplete.
                $( "#kata_kunci" ).autocomplete({
                    serviceUrl: "source.php",   // Kode php untuk prosesing data.
                    dataType: "",           // Tipe data JSON.
                    onSelect: function (suggestion) {
                        $( "#kata_kunci" ).val("" + suggestion.buah);
                    }
                });
            })
        </script>
        
<tr>
<br>


<form action="hasil.php" method="post">
	<h1><b style="color:blue;">K</b>
<b style="color:red;">R</b>
<b style="color:yellow;">I</b>
<b style="color:blue;">b</b>
<b style="color:green;">U</b>
<b style="color:red;">L</b>.com</h1>

<td>
		<INPUT  TYPE=text id="kotak" class="glyphicon glyphicon
		-search" name="kata_kunci" size=50 maxlength=500 value=""  x-webkit-speech onwebkitspeechchange="this.form.submit ();" placeholder=" Masukkan kata kunci">
		<INPUT type=submit name="submit" VALUE="Search" id="kotak">
		<font size="+1" style="font-family:Verdana, Arial, Helvetica, sans-serif">
		</font>
		</INPUT>
		</INPUT>
		</td>
	</form>
	</tr>
	</body>
	</center>
	
	<?php
	//jika tombol Cari di klik akan menjalankan script berikutnya
	if(isset($_POST['submit'])){
		//membuat variabel $kata_kunci yang menyimpan data dari inputan kata kunci
		$kata_kunci = $koneksi->real_escape_string(htmlentities(trim($_POST['kata_kunci'])));
		
		//cek apakah kata kunci kurang dari 3 karakter
		if(strlen($kata_kunci)<3){
			//pesan error jika kata kunci kurang dari 3 karakter
			echo '<p>masukkan Kata kunci!!</p>';
		}else{
			//membuat variabel $where dengan nilai kosong
			$where = "";
			
			//membuat variabel $kata_kunci_split untuk memecah kata kunci setiap ada spasi
			$kata_kunci_split = preg_split('/[\s]+/', $kata_kunci);
			//menghitung jumlah kata kunci dari split di atas
			$total_kata_kunci = count($kata_kunci_split);
			
			//melakukan perulangan sebanyak kata kunci yang di masukkan
			foreach($kata_kunci_split as $key=>$kunci){
				//set variabel $where untuk query nanti
				$where .= "kata_kunci LIKE '%$kunci%'";
				//jika kata kunci lebih dari 1 (2 dan seterusnya) maka di tambahkan OR di perulangannya
				if($key != ($total_kata_kunci - 1)){
					$where .= " OR ";
				}
			}
			
			//melakukan query ke database dengan SELECT, dan dimana WHERE ini mengambil dari $where
			$results = $koneksi->query("SELECT judul, LEFT(deskripsi, 60) as deskripsi, url FROM cari WHERE $where");
			//menghitung jumlah hasil query di atas
			$num = $results->num_rows;
			//jika tidak ada hasil
			if($num == 0){
				//pesan jika tidak ada hasil
				echo '<p>Pencarian dengan kata kunci <b>'.$kata_kunci.'</b> tidak ada hasil.</p>';
			}else{
				//pesan jika ada hasil pencarian
				echo '<p>Pencarian dari kata kunci <b>'.$kata_kunci.'</b> mendapatkan '.$num.' hasil:</p>';
				//perulangan untuk menampilkan data
				while($row = $results->fetch_assoc()){
					//menampilkan data
					echo '
					<p>
						<b>'.$row['judul'].'</b><br>
						'.$row['deskripsi'].'...<br>
						<a href="'.$row['url'].'">'.$row['url'].'</a>
					</p>
					';
				}
			}
		}
	}
	?>
	<center>
	<table>
	<td width="31%"></td>
	<td width="100%">
	<h4>punya situs atau blog masukkan<a href="admin/tambah.php"> disini..!</h4></a></center></h4></td>
	<td width="15"></td>
	</table>
	</center>
</body>
</html>


