
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>TeknikNih Mesin Pencari BIASAWAE</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta name="author" content="agus muhajir">
  <meta name="description" content="TeknikNih Mesin Pencari BIASAWAE">
  <meta name="url" content="http://tekniknih.com">
  <meta name="keywords" content="tekniknih, teknik, nih, mesin, pencari, biasawae, agus, muhajir, search, engine, google, yahoo, bing">


  <!-- Favicons -->
  <link href="http://tekniknih.com//template/img/users.png" rel="icon">




<meta property="fb:app_id" content="675775232575216"/>
<meta property="og:url" content="http://tekniknih.com" />
<meta property="og:title" content="TeknikNih Mesin Pencari BIASAWAE" />
<meta property="og:image" content="http://tekniknih.com//template/img/users.png" />
<meta property="og:description" content="TeknikNih Mesin Pencari BIASAWAE" />




  <!-- Bootstrap CSS File -->
  <link href="http://tekniknih.com//template/flatty/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="http://tekniknih.com//template/flatty/lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="http://tekniknih.com//template/flatty/css/style-biasawae.css" rel="stylesheet">

  <!-- =======================================================
    Template Name: Flatty
    Template URL: https://templatemag.com/flatty-bootstrap-app-landing-page-template/
    Author: TemplateMag.com
    License: https://templatemag.com/license/
    
    
    dan modifikasi oleh agus muhajir (http://github.com/hajirodeon)
  ======================================================= -->
  
    

<!-- Bootstrap core JavaScript -->
<script src="http://tekniknih.com//template/vendor/jquery/jquery.min.js"></script>
<script src="http://tekniknih.com//template/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>




  
<style> 
  #bgku {
    width: 100%;
    height: 100%;
    background-image: url('http://tekniknih.com//template/bg_random/10.jpg');
    background-size: cover;
}





</style>
</head>

<body>


<div id="bgku">
  

  <!-- Fixed navbar -->
  <div class="navbar navbar-default navbar-fixed-top">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        <a class="navbar-brand" href="http://tekniknih.com/"><b>TeknikNih</b></a>
      </div>




  <div class="navbar-collapse collapse navbar-right">
            <ul class="nav navbar-nav">

        <li><a href="http://tekniknih.com//kirim_url.php"><i class="fa fa-link"></i> KIRIM URL</a></li>

        <li><a href="http://tekniknih.com//pasang_iklan.php"><i class="fa fa-link"></i> PASANG IKLAN</a></li>

      </ul>
    </div>


      <!--/.nav-collapse -->
    </div>
  </div>



  <div id="headerwrap">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">

      


    <form action="hasil.php" method="post" name="formx" class="form-inline" role="form">
        <div class="form-group">

            <input name="kunci" id="kunci" type="text" class="form-control" value="" placeholder="Kamu Cari Saja Ya...">
        <input name="sesinya" id="sesinya" type="hidden" value="4376fe1e6c4f23f758f58fcc417fbbc7">

        </div>
      
            <button type="submit" class="btn btn-warning btn-lg" name="btnCARI" id="btnCARI"><span class="icon-magnifier search-icon"></span>OK. LANJUTKAN<i class="pe-7s-angle-right"></i></button>
            
    </form>



  <p>
  <i>***Cari Isi Dunia, dengan Penuh TeknikNih...</i>
  </p>

  
  


        </div>


      </div>
      <!-- /row -->
    </div>
    <!-- /container -->
  </div>
  <!-- /headerwrap -->




  <div id="contact">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2">

        </div>
      </div>
    </div>
  </div>
  <!-- / contact -->

  <div id="copyrights" style="width: 100%">
      <p>
        &copy; <strong>TeknikNih</strong>. 2018. <br>Powered by BIASAWAE
      </p>
        <!--
          You are NOT allowed to delete the credit link to TemplateMag with free version.
          You can delete the credit link only if you bought the pro version.
          Buy the pro version with working PHP/AJAX contact form: https://templatemag.com/flatty-bootstrap-app-landing-page-template/
          Licensing information: https://templatemag.com/license/
        -->

  </div>
  <!-- / copyrights -->




</div>


  <!-- JavaScript Libraries -->
  <script src="http://tekniknih.com//template/flatty/lib/jquery/jquery.min.js"></script>
  <script src="http://tekniknih.com//template/flatty/lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="http://tekniknih.com//template/flatty/lib/easing/easing.min.js"></script>

  <!-- Template Main Javascript File -->
  <script src="http://tekniknih.com//template/flatty/js/main.js"></script>














</body>
</html>
