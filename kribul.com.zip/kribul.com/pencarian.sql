-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 17 Sep 2018 pada 00.27
-- Versi Server: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pencarian`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `cari`
--

CREATE TABLE `cari` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `url` varchar(255) NOT NULL,
  `kata_kunci` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `cari`
--

INSERT INTO `cari` (`id`, `judul`, `deskripsi`, `url`, `kata_kunci`) VALUES
(1, 'Menampilkan Data MySQL dengan DataTables Server-side Processing (PHP, Bootstrap)', 'Tutorial bagaimana cara menampilkan data MySQL dengan DataTables Server-side processing dengan PHP dan Bootstrap', 'http://tutorialweb.net/menampilkan-data-mysql-dengan-datatables-server-side-processing-php-bootstrap/', 'menampilkan data mysql server side datatables php bootstrap'),
(2, 'Membuat Fasilitas Buku Tamu dengan PHP, MySQLi dan Bootstrap', 'Cara membuat buku tamu di website dengan bahasa pemrograman PHP dan database MySQL dan Bootstrap', 'http://tutorialweb.net/membuat-fasilitas-buku-tamu-dengan-php-mysqli-dan-bootstrap/', 'buku tamu/guestbook dengan php, mysql dan bootstrap'),
(3, '5 htaccess Trik Yang Harus Anda Ketahui', 'Trik terbaik dengan menggunakan htaccess', 'http://tutorialweb.net/5-htaccess-trik-yang-harus-anda-ketahui/', 'trik htaccess'),
(4, 'Membuat Halaman Dinamis Dengan PHP', 'Bagaimana membuat halaman dinamis dengan PHP', 'http://tutorialweb.net/membuat-halaman-dinamis-dengan-php/', 'halaman dinamis dengan php'),
(5, 'Membuat Coundown Timer Redirect dengan jQuery', 'Tutorial bagaimana cara membuat cound down timer dengan jQuery', 'http://tutorialweb.net/membuat-coundown-timer-redirect-dengan-jquery/', 'cound down timer jquery'),
(6, 'Simple & Pure CSS Dropdown Menu', 'Membuat dropdown menu dengan CSS murni yang sederhana', 'http://tutorialweb.net/simple-pure-css-dropdown-menu/', 'dropdown menu css'),
(7, 'Cara Installasi Joomla', 'Step by step instalasi CMS Joomla', 'http://tutorialweb.net/cara-installasi-joomla/', 'instalasi cms joomla'),
(8, 'cah sulo lasem', 'cah sulo lasem', 'https://cahsulolasem.blogspot.com', 'cah sulo lasem'),
(9, 'iqbal muttakin', 'seng penting dadi', 'https://iqbalmuttakin.wordpress.com/', 'iqbal muttakin'),
(10, 'smk cendekia lasem', 'smkcendekia lasem', 'https://smkcendekialasem.wordpress.com', 'smk cendekia lasem'),
(11, 'tv-online streaming', 'tv-online streaming', 'https://tvkustreaming.blogspot.com', 'tv online'),
(12, 'lasem kota wisata', 'wisata kajar', 'https://lasemkotawisata.blogspot.com', 'lasem kota wisata kajar'),
(13, 'muhammad iqbal-wikipedia', ' Muhammad Iqbal (Urdu: Ù…Ø­Ù…Ø¯ Ø§ÙÙ‚Ø¨Ø§Ù„ ) (November 9, 1877 â€“ April 21, 1938), widely known as Allama Iqbal, was a poet, philosopher and politician, as well as an ...', ' https://en.wikipedia.org/wiki/Muhammad_Iqbal', 'muhammad iqbal'),
(14, 'iqbal(film)-wikipedia', 'Iqbal (Hindi: à¤‡à¤•à¤¼à¥à¤¬à¤¾à¤²) is a 2005 Indian coming-of-age sports drama film written and directed by Nagesh Kukunoor. Produced by Subhash Ghai, under "Mukta ...', ' https://en.wikipedia.org/wiki/Iqbal_(film) ', 'iqbal(film)-wikipedia'),
(15, 'lowongan kerja terbaru di indonesia', 'lowongan kerja terbaru 2018 di indonesia', 'https://www.inlokerid.com', 'lowongan kerja terbaru di indonesia'),
(16, 'Tutorial PHP dan MySQL: Membuat Aplikasi CRUD [Studi Kasus Pendaftaran Siswa Baru]', 'Jun 10, 2017 - ... MongoDB, Ms. Access, dsb. Pada kesempatan ini, kita akan belajar menggunakan PHP dan MySQL untuk membuat aplikasi sederhana.', 'https://www.petanikode.com/tutorial-php-mysql/', 'Tutorial PHP dan MySQL: Membuat Aplikasi CRUD [Studi Kasus Pendaftaran Siswa Baru]'),
(17, 'Membuat Aplikasi CRUD Sederhana dengan PHP dan MySQL', 'Membuat Aplikasi CRUD Sederhana dengan PHP dan MySQL. Seperti judulnya yaitu Membuat Aplikasi CRUD (Create, Read, Update, Delete) Sederhana ', 'https://tutorialweb.net/membuat-aplikasi-crud-sederhana-dengan-php-dan-mysql/', 'Membuat Aplikasi CRUD Sederhana dengan PHP dan MySQL'),
(22, 'kabar nusantara', 'kabar nusantara terbaru dan terpercaya no hoax', 'https://kbrnusantara.blogspot.com', 'kabar nusantara'),
(23, 'Aneka Resep Nusantara ', 'aneka resep nusantara', ' http://bakery-nusantara.blogspot.com/', 'aneka resep nusantara'),
(24, ' Berita Hari Ini, Kabar Harian Terbaru Terkini Indonesia ... ', ' Liputan6com - Berita hari ini, kabar harian terbaru terkini Indonesia dan dunia Situs berita terpercaya seputar politik, peristiwa, bisnis, bola, tekno dan gosip artis', ' https://www.liputan6.com ', ' Berita Hari Ini, Kabar Harian Terbaru Terkini Indonesia .'),
(25, ' Berita Hari Ini, Kabar Harian Terbaru Terkini Indonesia ... ', ' Liputan6com - Berita hari ini, kabar harian terbaru terkini Indonesia dan dunia Situs berita terpercaya seputar politik, peristiwa, bisnis, bola, tekno dan gosip artis', ' https://www.liputan6.com ', ' Berita Hari Ini, Kabar Harian Terbaru Terkini Indonesia .'),
(26, ' Berita Terkini Hari Ini, Kabar Akurat Terpercaya - Kompas.com  ', 'Kompascom - Berita Indonesia dan Dunia Terkini Hari Ini, Kabar Harian Terbaru Terpercaya Terlengkap Seputar Politik, Ekonomi, Travel, Teknologi, Otomotif, Bola', 'https://www.kompas.com  ', ' Berita Terkini Hari Ini, Kabar Akurat Terpercaya - Kompas.com  '),
(27, ' Berita Hari Ini - Berita Harian Terbaru Terkini dan ...  ', '  Situs Berita harian terkini yang menyajikan berita hari ini dan kabar terbaru seputar politik hingga berita lifestyle dan olahraga', 'http://www.viva.co.id', 'Berita Hari Ini'),
(28, ' Okezone News :: Berita Dalam Negeri dan Internasional Terkini ', ' Okezone News menyajikan kabar info berita terhangat nasional dan internasional selebritis politik bola unik teknologi otomotif gaya hidup terkini di indonesia', ' https://news.okezone.com ', 'Okezone News :: Berita Dalam Negeri dan Internasional Terkini '),
(29, ' Video Gosip Artis - Kumpulan Video Terbaru Vidio.com ', ' Nonton Video entertainment gosip terkini para selebritis serta kabar terbaru para artis selengkapnya hanya di Vidiocom', ' https://www.vidio.com/categories/32-entertainment ', 'Video Gosip Artis - Kumpulan Video Terbaru Vidio.com '),
(30, ' Berita Regional Peristiwa Terbaru Hari Ini ', 'Kompascom - Berita Regional Terbaru Hari Ini, Menyajikan Kabar Berita Pemerintahan, Politik, Kriminal, Hukum Kabar Harian Peristiwa Terkini Regional Indonesia', ' https://regional.kompas.com  ', 'Berita Regional Peristiwa Terbaru Hari Ini '),
(31, ' Sejarah Nusantara (1942â€“1945) - Wikipedia bahasa â€¦', 'Sejarah Nusantara (1942â€“1945) - Wikipedia bahasa â€¦', '  https://id.wikipedia.org/wiki/Sejarah_Nusantara_(1942-1945) ', 'Sejarah Nusantara (1942â€“1945)'),
(32, ' Pujangga Jawa', '  Sang pujangga menggambarkan Majapahit sebagai pusat mandala raksasa yang membentang dari Sumatera ke Papua, mencakup Semenanjung Malaya dan Maluku Tradisi lokal di berbagai daerah di Nusantara masih mencatat kisah legenda mengenai kekuasaan Majapahit', '  http://pujangga-jawa.blogspot.com', ' Pujangga Jawa'),
(33, ' Cara Cepat Hamil - carakehamilansehat.blogspot.com', 'cara cepat hamil - Ciri-ciri hamil atau tanda kehamilan dapat dengan mudah dikenali Sehingga hal ini bisa menjadi kabar gembara bagi pasangan muda yang ingin mendambakan seorang anak Tanda ini biasanya diawali dengan adanya perubahan fisik pada ibu hamil', '  http://carakehamilansehat.blogspot.com  ', ' Cara Cepat Hamil '),
(34, 'Portal Info Lowongan Kerja di Semarang Jawa Tengah Terbaru ... ', '  Nine Stars Semarang, Perusahaan skala nasional yang berkantor pusat di Semarang dengan aktivitas bisnis disektor Perdagangan & Jasa Keuangan Dibutuhkan segera : ASSISTANT MANAGER (ASM) bus Pariwisata Premium, Trans Jakarta, BRT maupun bus VIP pesanan khusus Mari bergabung dengan tim sukses kami Saat ini kami membuka lowongan pekerjaan', ' http://www.lokersemarang.com', 'Portal Info Lowongan Kerja di Semarang Jawa Tengah Terbaru ... '),
(35, ' Contoh Surat Lamaran Kerja   ', 'Blog yang berisi tentang Contoh Surat Lamaran Kerja, Cara Membuat Surat Lamaran Pekerjaan, Contoh CV, Daftar Riwayat Hidup, Contoh Soal Psikotes dan Informasi Seputar Lowongan Kerja Terbaru', 'https://www.contohsuratlamarankerja.co.id ', ' Contoh Surat Lamaran Kerja   '),
(36, ' Contoh Surat Pengalaman Kerja dari Perusahaan  ', 'Contoh Surat Pengalaman Kerja dari Perusahaan wwwcontohsurat123com Close Klik 2x Contoh Surat Berbagi macam jenis contoh surat resmi niaga lamaran kerja pemberitahuan permohonan pribadi dinas perjanjian pengunduran diri kumpulan macam jenis baik dan benar terbaru tahun 2016 Setiap perusahaan ketika membuka lowongan tentu menetapkan', '  https://www.contohsurat123.com/.../contoh-surat-pengalaman-kerja.html', ' Contoh Surat Pengalaman Kerja dari Perusahaan'),
(37, ' Surat Lamaran Kerja', '  Surat Lamaran Kerja | Contoh Surat Lamaran Kerja Terbaru, Contoh CV Menarik, Download Contoh Surat Lamaran, Lowongan Kerja', '  http://www.surat-lamaran.com', ' Surat Lamaran Kerja'),
(38, ' Lowongan Kerja Indonesia | Cari dan Lamar Kerja | jobsDB ...   ', 'Melayani sejak tahun 1998, jobsDB selalu berusaha menyediakan info lowongan kerja Indonesia berkualitas Cari lowongan kerja terbaru disini!', ' https://id.jobsdb.com/id/id', ' Lowongan Kerja Indonesia | Cari dan Lamar Kerja'),
(39, ' Lowongan Kerja Contoh Surat Lamaran Kerja Administrasi ...  ', ' KARIRSUMUTCOM - Loker Medan Hari Ini 2018: Lowongan Kerja Contoh Surat Lamaran Kerja Administrasi Terbaru September 2018 - Update Lowongan Kerja Contoh Surat Lamaran Kerja Administrasi Terbaru September 2018, mungkin', ' https://karirsumut.com/contoh-surat-lamaran-kerja-administrasi.html', ' Lowongan Kerja Contoh Surat Lamaran Kerja Administrasi ...  '),
(40, ' Surat Lamaran Oto Finance | Lowongan Karir Kerja Indonesia ', '  Lowongan Kerja Drafter Sipil PT Tiga Pilar Sejahtera Food Tahun 2018 surat lamaran kerja rekan-rekan sekalian Berkas apa saja yang baiknya ada pada dlm surat lamaran kerja?Surat Lamaran telah barang tentu surat lamaran ialah hal yang paling utama dan di', ' http://www.lowongankaririndo.com/?s=surat+lamaran+oto+finance', ' http://www.lowongankaririndo.com/?s=surat+lamaran+oto+finance'),
(41, ' Contoh Surat Lamaran Kerja Teknisi - Dunia Kerja ', ' Kepada Yth, HRD Department PT Hal : Lamaran Pekerjaan, Dengan hormat, Bersama surat ini saya mengajukan lamaran pekerjaan di Perusahaan Bapak/Ibu untuk menempati posisi Teknisi, sehubungan dengan lowongan pekerjaan Perusahaan Bapak/Ibu di harian Kompas', '  http://fx-kerja.blogspot.com/2012/03/contoh-surat-lamaran-kerja-teknisi.html', ' Contoh Surat Lamaran Kerja Teknisi - Dunia Kerja '),
(42, ' Pengertian Surat Lamaran Kerja | Surat Lamaran Kerja ..', ' Contoh Surat Lamaran Kerja,Contoh CV/Resume,Info Lowongan Kerja,Tips Menulis Surat Lamaran kerja,Tips Wawancara', ' http://suratlamaranbekerja.blogspot.com/.../tentang-surat-lamaran-kerja.html ', 'Pengertian Surat Lamaran Kerja | Surat Lamaran Kerja ..'),
(43, ' Contoh Surat Lamaran Kerja - Download Surat Lamaran Kerja', '  Sumber informasi lowongan kerja dan tujuan menulis surat lamaran tersebut (sertakan posisi yang hendak dilamar) Sertakan didalam sebuah lamaran kerja dari mana sumber informasi lowongan kerja tersebut kamu peroleh dan apa tujuan kamu menulis surat lamaran tersebut (dalam hal ini tentu ingin melamar pekerjaan)', '  https://www.tipsinterview.net/contoh-surat-lamaran-kerja', ' Contoh Surat Lamaran Kerja - Download Surat Lamaran Kerja'),
(44, ' Lowongan Kerja PT. Pos Indonesia - lokerme.com ', 'Rekrutmen BUMN terbaru, Lowongan Kerja Bank, Lowongan CPNS, Bank, Lowongan Kerja Terbaru, Lowongan Swasta, Lowongan Kesehatan, Lowongan Tenaga Pendidik Menu Home; Lowongan Kerja Lampung; (Persero) di seluruh wilayah Republik Indonesia yang dinyatakan dengan Surat Pernyataan', ' https://www.lokerme.com/2018/07/rekrutmen-pt-pos-indonesia.html  ', ' Lowongan Kerja PT. Pos Indonesia - lokerme.com '),
(45, ' Contoh Surat Lamaran Kerja Sederhana ~ Situs Penyedia ...  ', ' Selamat Datang di Situs Penyedia Lowongan Kerja Semarang & Jawa Tengah Terbaru, Terlengkap dan Terpercaya INFO LOWONGAN CPNS 2012 - 2013 Buku Tamu Home Â» Contoh Surat Lamaran Kerja Â» Contoh Surat Lamaran Kerja Sederhana Contoh Surat Lamaran Kerja; Lowongan Kerja D3;', 'http://bursakerja-semarang.blogspot.com/2012/07/surat-lamaran-kerja.html ', ' Contoh Surat Lamaran Kerja Sederhana ~ Situs Penyedia ...  '),
(46, ' Lowongan Kerja: Surat lamaran Cilegon - Juli 2018 | Jooble', ' Kerja: Surat lamaran di Cilegon Cari di antara 29000+ lowongan kerja terbaru Pekerjaan penuh waktu, sementara dan paruh waktu Langganan informasi lowongan kerja Cepat & Gratis Pemberi kerja terbaik di Cilegon Kerja: Surat lamaran - dapat ditemukan dengan mudah!', '  https://id.jooble.org/lowongan-kerja-surat-lamaran/Cilegon ', 'Lowongan Kerja: Surat lamaran Cilegon - Juli 2018 | Jooble'),
(47, ' Contoh iklan lowongan pekerjaan staf hrd | Young HRD Indonesia ', '  Jasa Desain Surat Lamaran Kerja Info detail hubungi WA 085852316552 Mau Presentasi Sehebat Trainer ? LOWONGAN KERJA HRD Pasang Iklan Lowongan Pekerjaan Email ke [email protected] Posting Populer Kumpulan Ebook Manajemen Sumber Daya Manusia dan HRD Gratis', ' http://younghrd.blogspot.com/2013/...iklan-lowongan-pekerjaan-staf-hrd.html', ' Contoh iklan lowongan pekerjaan staf hrd | Young HRD Indonesia '),
(48, ' (LOKER) Lowongan Kerja di DKI Jakarta Hari Ini September 2018 ...  ', ' Saat ini, Telkomsigma membuka Lowongan Kerja BUMN untuk mengisi posisi sebagaiJava Periode pendaftaran 19 Agustus s/d 1 September 2018', 'https://job-like.com/joblist/area/dki_jakarta/ ', 'LOKER Lowongan Kerja di DKI Jakarta Hari Ini September 2018 ...  '),
(49, ' OpenKerja.com: Info Lowongan Kerja Terbaru September 2018   ', '  Ada perusahaan yang sedang membuka kesempatan lowongan kerja di daerah Bekasi, Staf Administrasi, Crew, Admin Health Processing Staff - Nfte dan', 'http://www.openkerja.com/', ' OpenKerja.com: Info Lowongan Kerja Terbaru September 2018   '),
(50, ' Lowongan September bulan Agustus 2018 | Indeed.com  ', 'Temukan ribuan info lowongan kerja / pekerjaan terbaru, untuk freshgraduate, part time, freelance, mahasiswa Ayo Apply Lamaranmu Sekarang, GRATIS!', 'https://id.indeed.com/lowongan-kerja-September  ', ' Lowongan September bulan Agustus 2018 | Indeed.com  '),
(51, ' Info Lowongan Kerja Terbaru September 2018 | TopKarir.com ', ' Lowongan Kerja September 2018 Lulusan SMA SMK D3 S1 Semua Jurusan Loker BANK BUMN September 2018', ' https://www.topkarir.com/lowongan ', ' Info Lowongan Kerja Terbaru September 2018 | TopKarir.com '),
(52, ' Lowongan Kerja September 2018 ', 'TerminalHRDcom - Lowongan Kerja PT Brantas Energi SEPTEMBER 2018 Lowongan kerja BUMN PT ASURANSI JIWASRAYA SEPTEMBER 2018 01/09/', ' https://www.lokerjobindo.com/2018/09/   ', ' Lowongan Kerja September 2018 '),
(53, 'Tutorial CRUD (Create, Read, Update dan Delete) Dengan ... ', 'Tutorial CRUD (Create, Read, Update dan Delete) Dengan ... ', ' http://www.tutorial-webdesign.com/tutorial-crud-create-read-update-dan-delete-dengan-codeigniter-part-2/', 'Tutorial CRUD (Create, Read, Update dan Delete) Dengan ... '),
(54, ' Tutorial CRUD PHP MySQL Dengan jQuery EasyUI - Belajarphp.net ', '  Jan 17, 2017 Easy UI adalah plugin jquery yang dapat membantu kita dalam membangun aplikasi berbasis web, terdapat banyak komponen yang sudah', ' https://belajarphp.net/tutorial-crud-php-mysql-dengan-jquery-easyui/ ', ' Tutorial CRUD PHP MySQL Dengan jQuery EasyUI - Belajarphp.net '),
(55, ' PHP MySQL CRUD Operations using jQuery and Bootstrap ', 'PHP MySQL crud tutorial to learn how to interact with MyQL from php and handle crud operations with jQuery and Bootstrap', ' https://www.itechempires.com/2016/03/php-mysql-crud-create-read-update-delete-operations-using-jquery/  ', ' PHP MySQL CRUD Operations using jQuery and Bootstrap '),
(56, ' Simple PHP Jquery Ajax CRUD(insert update delete) tutorial ... ', ' Nov 14, 2016 Today, I want to share with you PHP Mysql CRUD using Jquery Ajax from scratch CRUD stands for Create, Read, Update and Delete database', ' https://itsolutionstuff.com/post/simple-php-jquery-ajax-crudinsert-update-delete-tutorial-example-with-source-codeexample.html  ', ' Simple PHP Jquery Ajax CRUD(insert update delete) tutorial ... '),
(57, 'Data Pokok SMK CENDEKIA LASEM-Dapodikdasmen', 'Cabang KCP/Unit : LASEM. Rekening Atas Nama : SMK CENDEKIA LASEM. Luas Tanah Milik : 7495. Luas Tanah Bukan Milik : 1200. Data Rinci. Status BOS', 'http://dapo.dikdasmen.kemdikbud.go.id/sekolah/0934C9E23D9CBDB2A9F9', 'Data Pokok SMK CENDEKIA LASEM-Dapodikdasmen'),
(58, 'profil SMK CENDEKIA LASEM-PMP Dikdasmen', 'Profil SMK CENDEKIA LASEM Kirim Data PMP Terakhir : 2018-08-29 09:54: ... SUNAN BONANG KM.3 LASEM, RT/RW 7/4, Dsn. Sulo, Ds./Kel Sriombo, Kec.', 'http://pmp.dikdasmen.kemdikbud.go.id/sekolah/0934c9e23d9cbdb2a9f9', 'profil SMK CENDEKIA LASEM-PMP Dikdasmen'),
(59, 'smk cendikia lasem â€“ SMK CENDEKIA LASEM', ' smk cendikia lasem mempunyai 3 jurusan yang terdiri dari RPL(Rekayasa Perangkat Lunak), TSM(Teknik Sepeda Motor), dan MM (Multimedia) ...', ' https://smkcendekia.sch.id/smk-cendikia-lasem/ ', 'smk cendikia lasem'),
(60, 'Blogger: Profil User:Iqbalmuttakinblogger', 'My blogs. timnas u16 indonesia vs timnas u16 malaysia Â· Lasem kota wisata Â· SMK CENDEKIA LASEM Â· Cah Sulo lasem Â· tv-online streaming ...', 'https://www.blogger.com/profile/09915947854966731019', 'Blogger: Profil User:Iqbalmuttakinblogger'),
(61, 'Free Website Hosting: PHP, MySQL, Website Builder & Free Domain ... ', 'Get free website hosting with PHP, MySQL, free Website Builder & free domain name. ... databases, run your Cron jobs or simply leave everything on auto-pilot.', ' https://www.hostinger.com/free-hosting', 'Free Website Hosting: PHP, MySQL, Website Builder & Free Domain ... '),
(62, 'Absolutely Free Web Hosting with PHP, MySQL and No Ads', 'Get completely free website hosting with PHP , MySQL, free Website Builder, CPanel ... Easy to use Free Website Builder; WordPress Auto Installer; Full PHP ...', ' https://www.000webhost.com/ ', 'Absolutely Free Web Hosting with PHP, MySQL and No Ads'),
(63, ' Daftar Domain Dan Hosting Gratis Paling Populer (100% Free!) - Taryo â€º', ' Domain Hosting Translate this page Aug 19, 2013 - Berikut ini adalah daftar Domain dan Hosting Gratis untuk website anda, sudah ... Script Auto Installer : Ada (Wordpress); Addon Domain : Ada ...', ' https://blog.taryo.net', ' Daftar Domain Dan Hosting Gratis Paling Populer (100% Free!) - Taryo â€º'),
(64, 'Web hosting gratis Indonesia - Buat Website Tanpa Bayar', ' Translate this page Web hosting gratis Indonesia adalah platform yang tepat baik bagi pemula ... Bahkan di server web hosting juga telah tersedia WordPress auto-installer', ' https://id.hosting24.com/hosting-gratis', 'Web hosting gratis Indonesia - Buat Website Tanpa Bayar'),
(65, 'LimeDomains: Free web hosting, free domain name, free domain ...', 'one click blog hosting. affordable domain registration. domain search. wordpress hosting. free domain name. drupal, geeklog, joomla.', 'https:// www.gotonames.com/ ', 'LimeDomains: Free web hosting, free domain name, free domain ...'),
(66, 'DreamHost | Web Hosting For Your Purpose ', ' Shared Web Hosting gives you a free domain name, fast SSD storage and email ... Our many security features include Multi Factor Authentication, auto-enabled ..', 'https://www.dreamhost.com/', 'DreamHost | Web Hosting For Your Purpose '),
(67, 'Freeparking: Domain Names | Website Hosting | Email Hosting', 'NZ based authorised .nz Domain Name Registrar with 18 years of experience. Offering Domain Names, Website and Email Hosting and legendary customer ...', ' https://www.freeparking.co.nz/ ', 'Freeparking: Domain Names | Website Hosting | Email Hosting'),
(68, 'Hacker - Wikipedia', 'A computer hacker is any skilled computer expert that uses their technical knowledge to overcome a problem. While "hacker" can refer to any skilled computer ...', ' https://en.wikipedia.org/wiki/Hacker ', 'Hacker - Wikipedia'),
(69, 'Peretas - Wikipedia bahasa Indonesia, ensiklopedia bebas', 'Translate this page Peretas (bahasa Inggris: hacker) adalah orang yang mempelajari, menganalisis, memodifikasi, menerobos masuk ke dalam komputer dan jaringan komputer, ...', ' https://id.wikipedia.org/wiki/Peretas ', 'Peretas - Wikipedia bahasa Indonesia, ensiklopedia bebas'),
(70, 'Ethical Hacking - Learn How To Hack - Free Online Course | HackerOne ', ' Companies on our platform want to hear from you about potential security vulnerabilities they might have overlooked. By joining HackerOne, you can undertake ethical hacking on some of the most challenging and rewarding bounty programs. Hackers have earned more than $30 million (and ...', 'https://www.hackerone.com/start-hacking', 'Ethical Hacking - Learn How To Hack - Free Online Course | HackerOne '),
(71, 'The Hacker News â€“ Most Popular Cyber Security, Hacking News Site', 'News is the most popular cyber security and hacking news website read by every Information security professionals, infosec researchers and ...', ' https://thehackernews.com/ The Hacker ', 'The Hacker News â€“ Most Popular Cyber Security, Hacking News Site'),
(72, 'Cek Sound Cumi Cumi Audio Live Om Adella Candi Sidoarjo ...', ' Translate this page cek sound Cumi Cumi Audio Live Candi Sidoarjo 7 Januari 2018 instrumen ... Cek sound OM ADELLA CUMI CUMI DIGITAL AUDIO - Pria idaman instrumen ...', ' https://savetubevideo.com/cek-sound-cumi-cumi-audio-live-om-ad...', 'Cek Sound Cumi Cumi Audio Live Om Adella Candi Sidoarjo ...'),
(73, 'Cek sound OM ADELLA musik instrumen Cumi Cumi digital audio ...', ' Translate this page Chords for Cek sound OM ADELLA musik instrumen Cumi Cumi digital audio .. glerr..nya palang', ' https://chordify.net/.../cek-sound-om-adella-musik-instrumen-cumi-... ', 'Cek sound OM ADELLA musik instrumen Cumi Cumi digital audio ...'),
(74, 'Cek Sound Om Adella - Menunggu (cumi cumi digital audio) Chords ... ', 'Translate this page Chords for Cek Sound Om Adella - Menunggu (cumi cumi digital audio). Play along with guitar, ', 'https://chordify.net/.../cek-sound-om-adella-menunggu-cumi-cumi-... ', 'Cek Sound Om Adella - Menunggu (cumi cumi digital audio) Chords ... '),
(75, 'Skema Box 12" Untuk Mid Low Suara Mid Lantang - BANTOEL .COM  ', ' box12 Translate this page Feb 10, 2018 - Skema box 12" low mid yang mempunyai karakter suara lantang ... Lihat juga skema ukuran box speaker 12" lapangan yang tidak kalah bagus ..', 'https://www.bantoel.com', 'Skema Box 12" Untuk Mid Low Suara Mid Lantang - BANTOEL .COM  '),
(76, 'Skema Box Midle 10" Horn Tipe PA-MID-HI10 Untuk Lapangan ...', 'Box 10 Translate this page Feb 5, 2018 - Skema box midle tipe PA-MID-HI10 ini memang sangat cocok untuk ... Untuk hasil maksimal gunakan speaker berkualitas seperti RCF ..', ' https://www.bantoel.com', 'Skema Box Midle 10" Horn Tipe PA-MID-HI10 Untuk Lapangan ...'),
(77, 'Skema box speaker 12inch x2 lapangan suara jauh pro fullrange ... ', 'box 12inch baru Translate this page Jun 13, 2017 - Skema dan bentuk box speaker 12inch lapangan yang sangat bagus ... komponen speaker 12inch yang tidak kerucut alias karakter loe mid, ...', 'https://www.hazamusik.com ', 'Skema box speaker 12inch x2 lapangan suara jauh pro fullrange ... '),
(78, 'Jual Mixer Audio - Spesifikasi dan Harga - Galeri Musik Indonesia', 'Translate this page Kami jual semua merk dan model Mixer Audio Analog dan Digital terbaru. coba lihat perbandingan harga dan spesifikasi antar produk disini. Belanja online di ...', ' https://galerimusikindonesia.com/mixer-audio ', 'Jual Mixer Audio - Spesifikasi dan Harga - Galeri Musik Indonesia'),
(79, 'Mixer types | PA Beginners Guide | Self Training ... - Yamaha Pro Audio ', 'Self Training â€º PA Beginners Guide Mixers are items of equipment that arrange multiple input audio signals in a suitable balance, and they adjust tone quality so that the output audio is easy for the ...', 'https:// www.yamahaproaudio.com', 'Mixer types | PA Beginners Guide | Self Training ... - Yamaha Pro Audio '),
(80, 'Audio Mixer | Belajar mengenal Audio Mixer dan Fungsi Audio Mixer ', 'Translate this page Feb 6, 2016 - Audio Mixer, Fungsi audio Mixer, Pengertian Audio Mixer, Fungsi Gain Pada Mixer, Mixer Audio, Audio Mixer Fungsi Phantom Power, Audio ...', 'https://www.digiaudiostore.com/.../mengenal-fungsi-dan-fitur-pada-audio-mixer... ', 'Audio Mixer | Belajar mengenal Audio Mixer dan Fungsi Audio Mixer '),
(81, 'Aksesoris Audio Sound System â€“ Rakitan Murah Berkualitas ...', 'Selamat Datang Aksesoris Audio Sound System merupakan usaha kecil online yang berada di rumahan yang menjual berbagai Aksesoris Audio Sound.', ' https://aksesorisaudiosound.wordpress.com/ ', 'Aksesoris Audio Sound System â€“ Rakitan Murah Berkualitas ...'),
(82, 'ksesoris audio sound system lapangan.', ' Translate this page This entry was posted in audio processor, bbe, crossover, equalizer, mixer and tagged aksesoris audio sound system lapangan, aksesoris audio system untuk ...', ' https://aksesorisaudiosound.wordpress.com', 'ksesoris audio sound system lapangan.'),
(83, 'SOUND SYSTEM LAPANGAN ', ' Translate this page blog produk audio sound system seperti audio processor,crossover,power ampli,mixer,bbe,audio distributor.', 'https://etalasepro.blogspot.com/', 'SOUND SYSTEM LAPANGAN '),
(84, 'ANGKA KELUAR TOGEL HARI INI LIVE RESULT', 'Translate this page Data Angka Hasil Pengeluaran togel hari ini, prediksi angka togel jitu, togel hongkong hk, togel singapura sg sgp, sydney sd, macau, korea, kimtoto. ... DATA TOGEL LENGKAP. Data Angka Keluaran Togel Hari Ini dan predisi togel hari ini ..', 'http://resulttogel.top/hasil-togel-terbaru-hari-ini-live-result.html', 'ANGKA KELUAR TOGEL HARI INI LIVE RESULT'),
(85, 'Hasil Lengkap Keluaran Togel - Data Lengkap Pengeluaran Togel', ' Translate this page hasil lengkap keluaran togel, Data Lengkap Pengeluaran Togel, hasil keluaran angka togel, pengeluaran togel terlengkap, dukun togel indonesia.', 'https:// www1.warungtogel.com/index.php?hasillengkapkeluarantogel...1', 'Hasil Lengkap Keluaran Togel - Data Lengkap Pengeluaran Togel'),
(86, 'Hasil Lengkap Keluaran Togel - Data Lengkap Pengeluaran Togel ', 'Translate this page hasil lengkap keluaran togel, Data Lengkap Pengeluaran Togel, hasil keluaran angka togel, pengeluaran togel terlengkap, dukun togel indonesia.', 'https:// www1.warungtogel.com/index.php?hasillengkapkeluarantogel...1', 'Hasil Lengkap Keluaran Togel - Data Lengkap Pengeluaran Togel '),
(87, 'Data Angka Keluar Togel Lengkap Hari Ini | Live Result ', 'Translate this page Feb 15, 2018 - Data angka keluar togel live draw result, hk, hongkong, sgp, singapura, cambodia, sydney, china, taiwan, bulls eye, pcso, taipei, malaysia, ...', 'https://www.dataangka.com/ ', 'Data Angka Keluar Togel Lengkap Hari Ini | Live Result '),
(88, 'Rekayasa perangkat lunak - Wikipedia bahasa Indonesia ... ', 'Translate this page Rekayasa perangkat lunak (RPL, atau dalam bahasa Inggris: Software Engineering atau SE) adalah satu bidang profesi yang mendalami cara-cara ..', ' https://id.wikipedia.org/wiki/Rekayasa_perangkat_lunak', 'Rekayasa perangkat lunak - Wikipedia bahasa Indonesia ... '),
(89, '3 Kebiasaan Buruk Anak RPL - CodePolitan.com', 'Translate this page Feb 15, 2017 - Apa saja kebiasaan buruk yang dilakukan oleh anak RPL saat ini, sebenarnya perasaan ini sudah saya rasakan sejak duduk di kelas 1 ...', ' https://www.codepolitan.com/3-kebiasaan-buruk-anak-rpl-589b158... ', '3 Kebiasaan Buruk Anak RPL - CodePolitan.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `nama`, `username`, `password`) VALUES
(5, 'iqbal', 'iqbal', 'eedae20fc3c7a6e9c5b1102098771c70');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cari`
--
ALTER TABLE `cari`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cari`
--
ALTER TABLE `cari`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
