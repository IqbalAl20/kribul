<?php
//mulai proses tambah data

//cek dahulu, jika tombol tambah di klik
if(isset($_POST['kirim'])){
	
	//inlcude atau memasukkan file koneksi ke database
	include('koneksi.php');
	
	//jika tombol tambah benar di klik maka lanjut prosesnya
		//membuat variabel $nis dan datanya dari inputan NIS
	$judul		= $_POST['judul'];	//membuat variabel $nama dan datanya dari inputan Nama Lengkap
	$deskripsi		= $_POST['deskripsi'];	//membuat variabel $kelas dan datanya dari inputan dropdown Kelas
	$url	= $_POST['url'];	// vmembuatariabel $jurusan dan datanya dari inputan dropdown Jurusan
	$kata_kunci	= $_POST['kata_kunci'];
	
	//melakukan query dengan perintah INSERT INTO untuk memasukkan data ke database
	$input = mysql_query("INSERT INTO cari VALUES('', '$judul', '$deskripsi', '$url', '$kata_kunci')") or die(mysql_error());
	
	//jika query input sukses
	if($input){
		
		
		echo "<script>window.alert('situs/blog anda berhasil terkirim')
		window.location='tambah.php'</script>";
	}else{
		
		echo "<script>window.alert('situs/blog anda tidak terkirim')
		window.location='data.php'</script>";	}

}else{	//jika tidak terdeteksi tombol tambah di klik

	//redirect atau dikembalikan ke halaman tambah
	echo '<script>window.history.back()</script>';

}
?>