
<!DOCTYPE html>
<html>
<head>
	<title>tambah data kribul.com</title>
</head>
<body background="../Tulips.jpg">
	<h2></h2>
	
	<p><a href="../index.php">kembali ke awal</a>
	
	<h3>masukkan situs/blog di KRIBUL.com</h3>
	
	<form action="data-proses.php" method="post">
		<table cellpadding="3" cellspacing="0">
			<tr>
				<td>judul</td>
				<td>:</td>
				<td><input type="text" size="100" name="judul" required></td>
			</tr>
			<tr>
				<td>deskripsi</td>
				<td>:</td>
				<td><input type="text" size="100" name="deskripsi" size="30" required></td>
			</tr>
			<tr>
				<td>url</td>
				<td>:</td>
				<td><input type="text" size="100" name="url" size="30" placeholder="https://www.situs.com atau https://namablog.blogspot/wordpress.com" required></td>
			</tr>
			<tr>
				<td>kata kunci</td>
				<td>:</td>
				<td><input type="text" size="100" name="kata_kunci" size="30" required></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td></td>
				<td><input type="submit" name="kirim" value="kirim"></td>
			</tr>
		</table>
	</form>
</body>
</html>