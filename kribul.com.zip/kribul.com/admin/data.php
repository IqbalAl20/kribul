<?php 
include '../koneksi.php';

// mengaktifkan session
session_start();

// cek apakah user telah login, jika belum login maka di alihkan ke halaman login
if($_SESSION['status'] !="login"){
	header("location:../index.php");
}

// menampilkan pesan selamat datang
echo "Hai, selamat datang ". $_SESSION['username'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>data kribul.com</title>

	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css">
</head>
<body background="../Tulips.jpg">

<a href="logout.php">LOGOUT</a>
	<h1>Data kribul.com</h1>
	<p><a href="data.php">Beranda</a> / <a href="tambah.php">Tambah Data</a></p>
	
	<table id="dataTables" class="display" cellspacing="0" width="100%" border="1">

        <thead>
            <tr>
                <th>NO.</th>
                <th>judul</th>
                <th>deskripsi</th>
                <th>url</th>
                <th>kata kunci</th>
                <th>opsi</th>
                
            </tr>
        </thead>
		
		<tbody>
<?php  
		//iclude file koneksi ke database
		include('koneksi.php');
		

		//query ke database dg SELECT table siswa diurutkan berdasarkan NIS paling besar
		$query = mysql_query("SELECT * FROM cari ORDER BY id DESC") or die(mysql_error());
		
		//cek, apakakah hasil query di atas mendapatkan hasil atau tidak (data kosong atau tidak)
		if(mysql_num_rows($query) == 0){	//ini artinya jika data hasil query di atas kosong
			
			//jika data kosong, maka akan menampilkan row kosong
			echo '<tr><td colspan="6">Tidak ada data!</td></tr>';
			
		}else{	//else ini artinya jika data hasil query ada (data diu database tidak kosong)
			
			//jika data tidak kosong, maka akan melakukan perulangan while
			$no = 1;	//membuat variabel $no untuk membuat nomor urut
			while($data = mysql_fetch_assoc($query)){	//perulangan while dg membuat variabel $data yang akan mengambil data di database
				
				//menampilkan row dengan data di database
				echo '<tr>';
					echo '<td>'.$no.'</td>';	//menampilkan nomor urut
					echo '<td>'.$data['judul'].'</td>';	//menampilkan data nis dari database
					echo '<td>'.$data['deskripsi'].'</td>';	//menampilkan data nama lengkap dari database
					echo '<td>'.$data['url'].'</td>';	//menampilkan data kelas dari database
					echo '<td>'.$data['kata_kunci'].'</td>';	//menampilkan data jurusan dari database
					echo '<td><a href="edit.php?id='.$data['id'].'">Edit</a> / <a href="hapus.php?id='.$data['id'].'" onclick="return confirm(\'Yakin?\')">Hapus</a></td>';	//menampilkan link edit dan hapus dimana tiap link terdapat GET id -> ?id=siswa_id
				echo '</tr>';
				
				$no++;	//menambah jumlah nomor urut setiap row
				
			}
			
		}
		?>
		</tbody>
		<tfoot>
            <tr>
                <th>NO.</th>
                <th>judul</th>
                <th>deskripsi</th>
                <th>url</th>
                <th>kata_kunci</th>
                <th>opsi</th>
                
            </tr>
        </tfoot>
	</table>
	
	<script src="http://code.jquery.com/jquery-1.12.0.min.js"></script>
	<script src="//cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
	<script>
	$(document).ready(function() {
		$('#dataTables').DataTable();
	} );
	</script>

</body>
</html>