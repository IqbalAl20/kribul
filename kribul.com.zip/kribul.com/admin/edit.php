<!DOCTYPE html>
<html>
<head>
	<title>Edit data kribul.com</title>
</head>
<body background="../tulips.jpg">
	<h2></h2>
	
	<p><a href="data.php">Beranda</a> / <a href="tambah.php">Tambah Data</a></p>
	
	<h3>Edit Data Kribul.com</h3>
	
	<?php
	//proses mengambil data ke database untuk ditampilkan di form edit berdasarkan siswa_id yg didapatkan dari GET id -> edit.php?id=siswa_id
	
	//include atau memasukkan file koneksi ke database
	include('koneksi.php');
	
	//membuat variabel $id yg nilainya adalah dari URL GET id -> edit.php?id=siswa_id
	$id = $_GET['id'];
	
	//melakukan query ke database dg SELECT table siswa dengan kondisi WHERE siswa_id = '$id'
	$show = mysql_query("SELECT * FROM cari WHERE id='$id'");
	
	//cek apakah data dari hasil query ada atau tidak
	if(mysql_num_rows($show) == 0){
		
		//jika tidak ada data yg sesuai maka akan langsung di arahkan ke halaman depan atau beranda -> index.php
		echo '<script>window.history.back()</script>';
		
	}else{
	
		//jika data ditemukan, maka membuat variabel $data
		$data = mysql_fetch_assoc($show);	//mengambil data ke database yang nantinya akan ditampilkan di form edit di bawah
	
	}
	?>
	
	<form action="edit-proses.php" method="post">
		<input type="hidden" name="id" value="<?php echo $id; ?>">	<!-- membuat inputan hidden dan nilainya adalah siswa_id -->
		<table cellpadding="3" cellspacing="0">
			<tr>
			<tr>
				<td>sjudul</td>
				<td>:</td>
				<td><input type="text" name="judul" size="100" value="<?php echo $data['judul']; ?>" required></td>	<!-- value diambil dari hasil query -->
			</tr>
			<tr>
			<tr>
				<td>deskripsi</td>
				<td>:</td>
				<td><input type="text" name="deskripsi" size="100" value="<?php echo $data['deskripsi']; ?>" required></td> <!-- value diambil dari hasil query -->
			</tr>
			<tr>
				<td>url</td>
				<td>:</td>
				<td><input type="text" name="url" size="100" value="<?php echo $data['url']; ?>" required></td>	<!-- value diambil dari hasil query -->
			</tr>
			<tr>
				<td>kata kunci</td>
				<td>:</td>
				<td><input type="text" name="kata_kunci" size="100" value="<?php echo $data['kata_kunci']; ?>" required></td>	<!-- value diambil dari hasil query -->
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td></td>
				<td><input type="submit" name="simpan" value="Simpan"></td>
			</tr>
		</table>
	</form>
</body>
</html>