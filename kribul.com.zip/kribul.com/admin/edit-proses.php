<?php
//mulai proses edit data

//cek dahulu, jika tombol simpan di klik
if(isset($_POST['simpan'])){
	
	//inlcude atau memasukkan file koneksi ke database
	include('koneksi.php');
	
	//jika tombol tambah benar di klik maka lanjut prosesnya
	$id			= $_POST['id'];	//membuat variabel $id dan datanya dari inputan hidden id
	$judul		= $_POST['judul'];	//membuat variabel $nis dan datanya dari inputan NIS
	$deskripsi		= $_POST['deskripsi'];	//membuat variabel $nama dan datanya dari inputan Nama Lengkap
	$url		= $_POST['url'];	//membuat variabel $kelas dan datanya dari inputan dropdown Kelas
	$kata_kunci	= $_POST['kata_kunci'];	//membuat variabel $jurusan dan datanya dari inputan dropdown Jurusan
	
	//melakukan query dengan perintah UPDATE untuk update data ke database dengan kondisi WHERE siswa_id='$id' <- diambil dari inputan hidden id
	$update = mysql_query("UPDATE cari SET judul='$judul', deskripsi='$deskripsi', url='$url', kata_kunci='$kata_kunci' WHERE id='$id'") or die(mysql_error());
	
	//jika query update sukses
	if($update){
		
		
		echo "<script>window.alert('situs/blog anda berhasil di edit')
		window.location='data.php'</script>";
	}else{
		
		echo "<script>window.alert('situs/blog anda gagal di edit')
		window.location='data.php'</script>";	}


}else{	//jika tidak terdeteksi tombol simpan di klik

	//redirect atau dikembalikan ke halaman edit
	echo '<script>window.history.back()</script>';

}
?>