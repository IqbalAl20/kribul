<?php 
mysql_connect('localhost','root','');
$koneksi=mysql_select_db('pencarian');
?>