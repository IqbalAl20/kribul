<?php include 'koneksi.php';?>
<!DOCTYPE html>
<html>
<head>
<script async src"//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
	(adsbygoogle= window.adsbygoogle || []).push( {
		google_ad_client: "ca-pub-5594279754939735",
		enable_page_level_ads: true});
</script>
	<title>kribul.com</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<style>

b{
 font-size: 25px;
 font-family: Calibri;
 font-weight: normal;
}
.search_google{
    border: 1px solid #bbb;
    padding: 8px;
    width: 457px;
}
.btn{
border: 1px solid #bbb;
    padding: 10px;
    width: 60px;
   



}
.table{
	color: #color-green;
	

}
h2{
	color: #color-black;
	background-image: url();
	width: 12px;
	height:25 px;
}
</style>

<script src="jquery.js" type="text/javascript"></script>
<script type="text/javascript">
 $(document).ready(function(){
  $(".text-google").keyup(function(){
   $.ajax({
    url : "search_google.php",
    type: "POST",
    data: "keyword="+$(".text-google").val(),
    success : function(data){
     $(".result").html(data);
    }
   })
   
  })
 })
</script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>


		
</head>
<body>
<div class="result"></div>
<tr>
	
	<form action="hasil.php" method="post">


<center>
	
		<table bgcolor="#1E90FF" >
	<center>
	<tr>
	<td width="15%" bgcolor="#1E90FF"><a href="index.php">
		<h1><b style="color:blue;">K</b>
	<b style="color:red;">R</b>
<b style="color:yellow;">I</b>
	<b style="color:blue;">b</b>
		<b style="color:green;">U</b>
			<b style="color:red;">L</b></h1>
 	</a>
 </td>
		</center>
		<td width="100%">


	

		<input type="text" class="search_google" name="kata_kunci" placeholder="Masukkan kata kunci" value="">
		
		<input type="submit" name="submit" value="cari" class="btn btn-warning btn-lg" type="button">
			</td>
		<td width="25%"></td>
		</tr>

		</table>
</center>
	</form>
	</tr>
		<center>
	<table>
	<tr>
	<td width="5%"></td>
	
		<td width="100%">
		<br>
		<?php
	//jika tombol Cari di klik akan menjalankan script berikutnya
	if(isset($_POST['submit'])){
		//membuat variabel $kata_kunci yang menyimpan data dari inputan kata kunci
$kata_kunci = $koneksi->real_escape_string(htmlentities(trim($_POST['kata_kunci'])));
		
		//cek apakah kata kunci kurang dari 3 karakter
	if(strlen($kata_kunci)<3){
			//pesan error jika kata kunci kurang dari 3 karakter
		echo '<p>masukkan Kata kunci!!</p>';
	}else{
			//membuat variabel $where dengan nilai kosong
			$where = "";
			
			//membuat variabel $kata_kunci_split untuk memecah kata kunci setiap ada spasi
			$kata_kunci_split = preg_split('/[\s]+/', $kata_kunci);
			//menghitung jumlah kata kunci dari split di atas
			$total_kata_kunci = count($kata_kunci_split);
			
			//melakukan perulangan sebanyak kata kunci yang di masukkan
			foreach($kata_kunci_split as $key=>$kunci){
				//set variabel $where untuk query nanti
				$where .= "kata_kunci LIKE '%$kunci%'";
				//jika kata kunci lebih dari 1 (2 dan seterusnya) maka di tambahkan OR di perulangannya
				if($key != ($total_kata_kunci - 1)){
					$where .= " OR ";
				}
			}
			
			//melakukan query ke database dengan SELECT, dan dimana WHERE ini mengambil dari $where
			$results = $koneksi->query("SELECT judul, LEFT(deskripsi, 60) as deskripsi, url FROM cari WHERE $where");
			//menghitung jumlah hasil query di atas
			$num = $results->num_rows;
			//jika tidak ada hasil
			if($num == 0){
				//pesan jika tidak ada hasil
				echo '<p>Pencarian dengan kata kunci <b>'.$kata_kunci.'</b> tidak ada hasil.</p>';
			}else{
				//pesan jika ada hasil pencarian
				echo '<p>Pencarian dari kata kunci <b>'.$kata_kunci.'</b> mendapatkan  '.$num.' hasil:</p><hr>';
				//perulangan untuk menampilkan data
				while($row = $results->fetch_assoc()){
					//menampilkan data
					echo '
					<p>
						<b><a href="'.$row['url'].'">'.$row['judul'].'</b></a><br>
						'.$row['deskripsi'].'...<br>
						'.$row['url'].'</a><hr>
					</p>
					';
				}
			}
		}
	}
	?>

		
	</td>

		<td width="5%">
			

		</td>
	
	</tr>
	</table>
	</center>
	<center>
	
	

	<table bgcolor="#1E90FF">
		<tr>
			<td width="2%"></td>
			<td width="100%"><center><H6>
<div id="copyrights" style="width: 100%">
      <p>
        &copy; <strong>Kribul.com</strong>. 2018. <br>Powered by seng penteng dadi
      </p>
  </td>
			<td width="25%"></td>
		</tr>
	</table>
	
</center>
</body>
</html>